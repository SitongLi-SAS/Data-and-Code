#!/bin/sh

cython minepy/mine.pyx
