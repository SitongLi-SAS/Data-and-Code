INSTALL
=======

See the online documentation at http://minepy.readthedocs.io.
